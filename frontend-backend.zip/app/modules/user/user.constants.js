 const UserSearchAbleFields = ['FirstName' , 'LastName', 'Status', 'id', 'Email'];
 const UserFilterAbleFileds = ['searchTerm', 'Branch', 'FirstName' , 'LastName', 'Profile', 'Role', 'Status', 'id', 'Email', ]; // Now used for exact filter
 

 module.exports = {
    UserFilterAbleFileds,
    UserSearchAbleFields
 }